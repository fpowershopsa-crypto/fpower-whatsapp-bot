#!/usr/bin/env bash
# F POWER bot — one-time server setup. Run on a fresh Ubuntu server as root:
#   bash setup.sh
set -euo pipefail
cd "$(dirname "$0")"

echo "==> 1/5 تثبيت Docker (إذا مو موجود)"
if ! command -v docker >/dev/null; then
  curl -fsSL https://get.docker.com | sh
fi

echo "==> 2/5 تجهيز ملف الإعدادات .env"
if [ ! -f .env ]; then
  cp .env.example .env
  IP=$(curl -fsS https://api.ipify.org)
  DOMAIN="${IP//./-}.sslip.io"
  rnd() { openssl rand -hex "$1"; }
  sed -i "s#^CHAT_DOMAIN=.*#CHAT_DOMAIN=${DOMAIN}#" .env
  sed -i "s#^WEBHOOK_SECRET=.*#WEBHOOK_SECRET=$(rnd 16)#" .env
  sed -i "s#^SECRET_KEY_BASE=.*#SECRET_KEY_BASE=$(rnd 64)#" .env
  sed -i "s#^POSTGRES_PASSWORD=.*#POSTGRES_PASSWORD=$(rnd 16)#" .env
  sed -i "s#^REDIS_PASSWORD=.*#REDIS_PASSWORD=$(rnd 16)#" .env
  read -rp "الصق مفتاح Claude (يبدأ بـ sk-ant-) ثم Enter: " KEY
  sed -i "s#^ANTHROPIC_API_KEY=.*#ANTHROPIC_API_KEY=${KEY}#" .env
fi
set -a; . ./.env; set +a

echo "==> 3/5 تجهيز قاعدة بيانات Chatwoot (أول مرة تاخذ دقايق)"
docker compose pull rails sidekiq postgres redis caddy
docker compose up -d postgres redis
sleep 10
docker compose run --rm rails bundle exec rails db:chatwoot_prepare

echo "==> 4/5 تشغيل كل شي"
docker compose up -d --build

echo "==> 5/5 جاهز ✅"
echo "افتح صندوق المحادثات: https://${CHAT_DOMAIN}"
echo "رابط البوت (تحتاجه في الخطوة 6): https://${CHAT_DOMAIN}/fpower-agent/webhook?token=${WEBHOOK_SECRET}"
echo "بعد ما تحط CHATWOOT_BOT_TOKEN و CHATWOOT_USER_TOKEN في ملف .env شغّل:  docker compose up -d agent"
