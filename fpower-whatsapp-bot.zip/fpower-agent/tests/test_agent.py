"""Offline tests: no real Claude, Chatwoot or Zid calls (except catalog, which is mocked)."""
import datetime as dt
from types import SimpleNamespace as NS
from unittest import mock

import pytest
from fastapi.testclient import TestClient

from app import agent, catalog, chatwoot, config, orders

FAKE_CATALOG = [
    {"id": "p1", "name": "كمبيوتر هالتك ايليت 550", "sku": "HT-550", "price": 3999.0, "sale_price": None,
     "has_options": False, "in_stock": True, "categories": ["قطع كهربائية"], "url": "https://fpowerksa.com/products/haltech-550",
     "description": "كمبيوتر برمجة كامل"},
    {"id": "p2", "name": "تيربو PSR 5449G رولمان بلي - لين 660 حصان", "sku": "T1", "price": 4049.0, "sale_price": None,
     "has_options": True, "in_stock": True, "categories": ["قطع المكينة"], "url": "https://fpowerksa.com/products/t1",
     "description": "تيربو"},
    {"id": "p3", "name": "بخاخات داينامكس 1050", "sku": "INJ", "price": 2399.0, "sale_price": 1999.0,
     "has_options": False, "in_stock": False, "categories": ["قطع المكينة"], "url": "https://fpowerksa.com/products/inj",
     "description": "بخاخات"},
]


@pytest.fixture(autouse=True)
def fake_catalog(monkeypatch):
    monkeypatch.setattr(catalog, "_products", list(FAKE_CATALOG))
    monkeypatch.setattr(catalog, "_loaded_at", 1e12)  # never stale


# ---------- fake Claude ----------
def text(t):
    return NS(type="text", text=t)


def tool(name, inp, id_="t1"):
    return NS(type="tool_use", name=name, input=inp, id=id_)


class FakeClaude:
    def __init__(self, script):
        self.script = list(script)
        self.calls = []
        self.messages = self

    def create(self, **kw):
        self.calls.append(kw)
        content, stop = self.script.pop(0)
        return NS(content=content, stop_reason=stop)


# ---------- catalog ----------
def test_search_finds_haltech_by_arabic_and_english():
    assert catalog.search("هالتك 550")[0]["id"] == "p1"
    assert catalog.search("haltech")[0]["id"] == "p1"
    assert catalog.search("تربو 660")[0]["id"] == "p2"


def test_search_view_has_sale_price_and_options_note():
    inj = catalog.search("بخاخات")[0]
    assert inj["price_sar"] == 1999.0 and inj["old_price_sar"] == 2399.0 and inj["in_stock"] is False
    turbo = catalog.search("تيربو")[0]
    assert turbo["price_note"]


def test_search_nonsense_returns_nothing():
    assert catalog.search("بيتزا") == []


# ---------- agent loop ----------
def test_product_question_uses_search_tool():
    fake = FakeClaude([
        ([tool("search_products", {"query": "هالتك 550"})], "tool_use"),
        ([text("كمبيوتر هالتك ايليت 550 سعره 3999 ريال ومتوفر 👍")], "end_turn"),
    ])
    r = agent.respond([{"role": "user", "content": "كم سعر الهالتك 550؟"}], "+966500000001", client=fake)
    assert "3999" in r.reply and r.handoff_reason is None
    assert r.tool_calls[0]["output"]["results"][0]["id"] == "p1"
    # tool result was sent back to Claude
    assert fake.calls[1]["messages"][-1]["content"][0]["type"] == "tool_result"


def test_compatibility_question_hands_off(monkeypatch):
    monkeypatch.setattr(agent, "_within_support_hours", lambda now=None: True)
    fake = FakeClaude([
        ([tool("handoff_to_human", {"reason": "سؤال توافق هالتك مع فتك 2017"})], "tool_use"),
        ([text("أبشر، حولتك لأحد الفريق يتأكد من التوافق 🙏")], "end_turn"),
    ])
    r = agent.respond([{"role": "user", "content": "يركب على فتك 2017؟"}], "+966500000001", client=fake)
    assert r.handoff_reason == "سؤال توافق هالتك مع فتك 2017"
    assert "قريب" in r.tool_calls[0]["output"]["note"]


def test_after_hours_handoff_note(monkeypatch):
    monkeypatch.setattr(agent, "_within_support_hours", lambda now=None: False)
    out = agent._run_tool("handoff_to_human", {"reason": "x"}, "", {})
    assert "9 الصبح" in out["note"]


def test_support_hours_window():
    tz = dt.timezone(dt.timedelta(hours=3))
    assert agent._within_support_hours(dt.datetime(2026, 10, 6, 10, tzinfo=tz))
    assert not agent._within_support_hours(dt.datetime(2026, 10, 6, 23, 30, tzinfo=tz))
    assert not agent._within_support_hours(dt.datetime(2026, 10, 6, 3, tzinfo=tz))


def test_endless_tool_loop_falls_back_to_handoff():
    fake = FakeClaude([([tool("search_products", {"query": "x"})], "tool_use")] * config.MAX_TOOL_ROUNDS)
    r = agent.respond([{"role": "user", "content": "؟"}], "", client=fake)
    assert r.handoff_reason and "الفريق" in r.reply


def test_system_prompt_is_cached_and_has_policies():
    fake = FakeClaude([([text("هلا")], "end_turn")])
    agent.respond([{"role": "user", "content": "هلا"}], "", client=fake)
    sys_block = fake.calls[0]["system"][0]
    assert sys_block["cache_control"]["type"] == "ephemeral"
    assert "30 ريال" in sys_block["text"] and "تابي" in sys_block["text"]


# ---------- orders ----------
def test_order_tracking_not_connected(monkeypatch):
    monkeypatch.setattr(config, "ZID_AUTHORIZATION", "")
    assert orders.lookup("123", "+966500000001") == {"error": "order_tracking_not_connected"}


def test_order_hidden_when_phone_differs(monkeypatch):
    monkeypatch.setattr(config, "ZID_AUTHORIZATION", "a")
    monkeypatch.setattr(config, "ZID_MANAGER_TOKEN", "b")
    resp = NS(status_code=200, json=lambda: {"order": {"id": 123, "customer": {"mobile": "966511111111"},
                                                         "order_status": {"code": "indelivery"}}})
    with mock.patch("httpx.get", return_value=resp):
        assert orders.lookup("123", "+966500000001") == {"error": "phone_does_not_match_order"}
        ok = orders.lookup("123", "0511111111")
    assert ok["status"] == "انشحن وفي الطريق لك"


# ---------- chatwoot history ----------
def test_history_skips_private_and_merges():
    msgs = [
        {"id": 1, "created_at": 1, "message_type": 0, "content": "السلام"},
        {"id": 2, "created_at": 2, "message_type": 0, "content": "عندي سؤال"},
        {"id": 3, "created_at": 3, "message_type": 1, "content": "ملاحظة", "private": True},
        {"id": 4, "created_at": 4, "message_type": 1, "content": "هلا وغلا"},
        {"id": 5, "created_at": 5, "message_type": 0, "content": "", "attachments": [{"file_type": "audio"}]},
    ]
    h = chatwoot.to_history(msgs)
    assert h == [
        {"role": "user", "content": "السلام\nعندي سؤال"},
        {"role": "assistant", "content": "هلا وغلا"},
        {"role": "user", "content": "[أرسل العميل مرفق: audio]"},
    ]


# ---------- webhook filter ----------
def test_webhook_filters(monkeypatch):
    from app import main
    monkeypatch.setattr(config, "WEBHOOK_SECRET", "s3cret")
    monkeypatch.setattr(main.catalog, "refresh", lambda force=False: 3)
    handled = []
    monkeypatch.setattr(main, "_handle", lambda data: handled.append(data["id"]))
    c = TestClient(main.app)
    base = {"event": "message_created", "message_type": "incoming", "conversation": {"id": 9, "status": "pending"}}
    assert c.post("/webhook?token=wrong", json={**base, "id": 1}).status_code == 403
    assert c.post("/webhook?token=s3cret", json={**base, "id": 2}).json() == {"queued": True}
    assert "skipped" in c.post("/webhook?token=s3cret", json={**base, "id": 2}).json()  # duplicate
    assert "skipped" in c.post("/webhook?token=s3cret", json={**base, "id": 3, "message_type": "outgoing"}).json()
    human = {**base, "id": 4, "conversation": {"id": 9, "status": "open"}}
    assert "skipped" in c.post("/webhook?token=s3cret", json=human).json()
    assert handled == [2]


# ---------- full handling with fake Chatwoot ----------
def test_handle_replies_and_hands_off(monkeypatch):
    import asyncio
    from app import main
    monkeypatch.setattr(main, "DEBOUNCE_SECONDS", 0)
    monkeypatch.setattr(config, "CHATWOOT_USER_TOKEN", "u")
    sent, handed = [], []

    async def get_messages(cid):
        return [{"id": 7, "created_at": 1, "message_type": 0, "content": "ابي تقسيط تمارا"}]

    async def send_message(cid, content, private=False):
        sent.append(content)

    async def hand_off(cid, reason):
        handed.append(reason)

    monkeypatch.setattr(main.chatwoot, "get_messages", get_messages)
    monkeypatch.setattr(main.chatwoot, "send_message", send_message)
    monkeypatch.setattr(main.chatwoot, "hand_off", hand_off)
    monkeypatch.setattr(main.agent, "respond",
                        lambda h, p, n: agent.AgentResult("أبشر، حولتك للفريق 🙏", "تقسيط تمارا"))
    data = {"id": 7, "conversation": {"id": 9, "meta": {"sender": {"phone_number": "+966500000001", "name": "Ali"}}},
            "sender": {"phone_number": "+966500000001", "name": "Ali"}}
    asyncio.run(main._handle(data))
    assert sent == ["أبشر، حولتك للفريق 🙏"] and handed == ["تقسيط تمارا"]


def test_handle_skips_when_newer_message_exists(monkeypatch):
    import asyncio
    from app import main
    monkeypatch.setattr(main, "DEBOUNCE_SECONDS", 0)
    monkeypatch.setattr(config, "CHATWOOT_USER_TOKEN", "u")

    async def get_messages(cid):
        return [{"id": 7, "created_at": 1, "message_type": 0, "content": "هلا"},
                {"id": 8, "created_at": 2, "message_type": 0, "content": "عندي سؤال"}]

    called = []
    monkeypatch.setattr(main.chatwoot, "get_messages", get_messages)
    monkeypatch.setattr(main.agent, "respond", lambda *a: called.append(1))
    asyncio.run(main._handle({"id": 7, "conversation": {"id": 9}}))
    assert called == []


def test_handle_error_still_answers_and_hands_off(monkeypatch):
    import asyncio
    from app import main
    monkeypatch.setattr(main, "DEBOUNCE_SECONDS", 0)
    monkeypatch.setattr(config, "CHATWOOT_USER_TOKEN", "u")
    sent, handed = [], []

    async def get_messages(cid):
        return [{"id": 7, "created_at": 1, "message_type": 0, "content": "هلا"}]

    async def send_message(cid, content, private=False):
        sent.append(content)

    async def hand_off(cid, reason):
        handed.append(reason)

    def boom(*a):
        raise RuntimeError("claude down")

    monkeypatch.setattr(main.chatwoot, "get_messages", get_messages)
    monkeypatch.setattr(main.chatwoot, "send_message", send_message)
    monkeypatch.setattr(main.chatwoot, "hand_off", hand_off)
    monkeypatch.setattr(main.agent, "respond", boom)
    asyncio.run(main._handle({"id": 7, "conversation": {"id": 9}}))
    assert sent and handed


def test_handle_stays_quiet_after_human_reply(monkeypatch):
    import asyncio
    from app import main
    monkeypatch.setattr(main, "DEBOUNCE_SECONDS", 0)
    monkeypatch.setattr(config, "CHATWOOT_USER_TOKEN", "u")
    opened, called = [], []

    async def get_messages(cid):
        return [{"id": 6, "created_at": 1, "message_type": 1, "content": "هلا، معك زياد", "sender": {"type": "user"}},
                {"id": 7, "created_at": 2, "message_type": 0, "content": "تمام"}]

    async def open_conversation(cid):
        opened.append(cid)

    monkeypatch.setattr(main.chatwoot, "get_messages", get_messages)
    monkeypatch.setattr(main.chatwoot, "open_conversation", open_conversation)
    monkeypatch.setattr(main.agent, "respond", lambda *a: called.append(1))
    asyncio.run(main._handle({"id": 7, "conversation": {"id": 9}}))
    assert called == [] and opened == [9]


def test_handle_without_user_token_uses_webhook_message(monkeypatch):
    import asyncio
    from app import main
    monkeypatch.setattr(main, "DEBOUNCE_SECONDS", 0)
    monkeypatch.setattr(config, "CHATWOOT_USER_TOKEN", "")
    seen, sent = [], []

    async def get_messages(cid):
        raise AssertionError("bot token cannot list messages")

    async def send_message(cid, content, private=False):
        sent.append(content)

    monkeypatch.setattr(main.chatwoot, "get_messages", get_messages)
    monkeypatch.setattr(main.chatwoot, "send_message", send_message)
    monkeypatch.setattr(main.agent, "respond", lambda h, p, n: seen.append(h) or agent.AgentResult("هلا"))
    data = {"id": 7, "message_type": "incoming", "content": "كم سعر الهالتك؟", "created_at": "2026-10-06T10:00:00Z",
            "conversation": {"id": 9}}
    asyncio.run(main._handle(data))
    assert seen == [[{"role": "user", "content": "كم سعر الهالتك؟"}]] and sent == ["هلا"]


def test_handoff_failure_after_reply_does_not_send_second_message(monkeypatch):
    import asyncio
    from app import main
    monkeypatch.setattr(main, "DEBOUNCE_SECONDS", 0)
    monkeypatch.setattr(config, "CHATWOOT_USER_TOKEN", "u")
    sent = []

    async def get_messages(cid):
        return [{"id": 7, "created_at": 1, "message_type": 0, "content": "تمارا"}]

    async def send_message(cid, content, private=False):
        sent.append(content)

    async def hand_off(cid, reason):
        raise RuntimeError("chatwoot down")

    monkeypatch.setattr(main.chatwoot, "get_messages", get_messages)
    monkeypatch.setattr(main.chatwoot, "send_message", send_message)
    monkeypatch.setattr(main.chatwoot, "hand_off", hand_off)
    monkeypatch.setattr(main.agent, "respond", lambda h, p, n: agent.AgentResult("حولتك 🙏", "تقسيط"))
    asyncio.run(main._handle({"id": 7, "conversation": {"id": 9}}))
    assert sent == ["حولتك 🙏"]


def test_latest_orders_needs_a_real_phone(monkeypatch):
    monkeypatch.setattr(config, "ZID_AUTHORIZATION", "a")
    monkeypatch.setattr(config, "ZID_MANAGER_TOKEN", "b")
    resp = NS(status_code=200, json=lambda: {"orders": [{"id": 1, "customer": {"mobile": None}}]})
    with mock.patch("httpx.get", return_value=resp):
        assert orders.latest_for_phone("") == {"error": "no_orders_for_this_phone"}
        assert orders.lookup("1", "") == {"error": "phone_does_not_match_order"}


def test_empty_cache_file_does_not_crash(monkeypatch, tmp_path):
    cache = tmp_path / "catalog.json"
    cache.write_text("")
    monkeypatch.setattr(catalog, "_CACHE_FILE", str(cache))
    monkeypatch.setattr(catalog, "_products", [])

    def down():
        raise RuntimeError("zid down")

    monkeypatch.setattr(catalog, "_fetch_all", down)
    assert catalog.refresh(True) == 0
