"""Product catalog: pulled from Zid's public storefront API (no token needed),
cached on disk, and searched locally with Arabic-aware matching."""
import html
import math
import json
import os
import re
import threading
import time

import httpx

from . import config

_API = "https://api.zid.sa/v1/products/"
_lock = threading.Lock()
_products: list[dict] = []
_loaded_at = 0.0
_CACHE_FILE = os.path.join(config.DATA_DIR, "catalog.json")

# ---------- text normalisation ----------
_DIACRITICS = re.compile(r"[ؗ-ًؚ-ْٰـ]")


def normalize(text: str) -> str:
    text = (text or "").lower()
    text = _DIACRITICS.sub("", text)
    text = re.sub("[إأآٱ]", "ا", text)
    text = text.replace("ى", "ي").replace("ة", "ه").replace("ؤ", "و").replace("ئ", "ي")
    text = re.sub(r"[^\w\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _strip_html(raw: str) -> str:
    text = re.sub(r"<[^>]+>", " ", raw or "")
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


# Words customers use -> the words that appear in product names (groups match each other)
_GROUPS = [
    ["تيربو", "تربو", "turbo", "تيربوو", "تربوو"],
    ["هالتك", "haltech", "هالتيك"],
    ["ماكسس", "maxxecu", "maxx", "ماكس"],
    ["كمبيوتر", "ecu", "كمبيوتر"],
    ["شكمان", "عادم", "اكزوز", "exhaust", "دبه"],
    ["داون", "downpipe", "داونبايب"],
    ["انتركولر", "intercooler", "انتر"],
    ["بخاخ", "بخاخات", "injector", "injectors", "انجكتر"],
    ["طرمبه", "طرمبة", "pump", "مضخه"],
    ["رديتر", "radiator", "ردياتير"],
    ["انتيك", "intake", "فلتر هوا"],
    ["بي", "bmw", "بيم", "بمو"],
    ["فتك", "vtc", "باترول", "patrol"],
    ["لاندكروزر", "لاند", "landcruiser", "شاص"],
    ["كلتش", "clutch", "دبرياج"],
    ["بواجي", "spark", "شمعات"],
    ["كاربون", "carbon"],
]
_ALIASES: dict[str, set[str]] = {}
for _g in _GROUPS:
    _forms = {normalize(w) for w in _g}
    for _w in _forms:
        _ALIASES.setdefault(_w, set()).update(_forms)


def _stem(word: str) -> str:
    """Drop Arabic prefixes like ال / لل / ل so 'لمكينه' matches 'مكينه'."""
    for pre in ("وال", "بال", "لل", "ال"):
        if word.startswith(pre) and len(word) - len(pre) >= 3:
            return word[len(pre):]
    if word.startswith("ل") and len(word) >= 5:
        return word[1:]
    return word


def _text(value) -> str:
    """Zid may return translatable fields as {"ar": ..., "en": ...}."""
    if isinstance(value, dict):
        value = value.get("ar") or value.get("en") or next(iter(value.values()), "")
    return str(value or "").strip()


def _simplify(p: dict) -> dict:
    cats = [c.get("name", "") for c in p.get("categories") or []]
    price = p.get("price")
    sale = p.get("sale_price")
    in_stock = bool(p.get("is_infinite")) or (p.get("quantity") or 0) > 0
    return {
        "id": p.get("id"),
        "name": _text(p.get("name")),
        "sku": p.get("sku") or "",
        "price": price,
        "sale_price": sale,
        "has_options": bool(p.get("has_options")),
        "in_stock": in_stock,
        "categories": cats,
        "url": p.get("html_url") or "",
        "description": _strip_html(p.get("short_description") or p.get("description") or "")[:600],
    }


def _fetch_all() -> list[dict]:
    headers = {"Store-Id": config.ZID_STORE_ID, "Role": "Customer", "Accept-Language": "ar"}
    out, page = [], 1
    with httpx.Client(timeout=30) as client:
        while True:
            r = client.get(_API, params={"page": page, "page_size": 100}, headers=headers)
            r.raise_for_status()
            data = r.json()
            out.extend(_simplify(p) for p in data.get("results", []) if not p.get("is_draft"))
            if not data.get("next"):
                break
            page += 1
            if page > 50:  # safety stop
                break
    return out


def refresh(force: bool = False) -> int:
    """Reload the catalog if it is older than the refresh interval. Returns product count."""
    global _products, _loaded_at
    with _lock:
        stale = time.time() - _loaded_at > config.CATALOG_REFRESH_MINUTES * 60
        if _products and not stale and not force:
            return len(_products)
        try:
            items = _fetch_all()
            if items:
                _products, _loaded_at = items, time.time()
                os.makedirs(config.DATA_DIR, exist_ok=True)
                with open(_CACHE_FILE, "w", encoding="utf-8") as f:
                    json.dump(items, f, ensure_ascii=False)
        except Exception:
            # Zid unreachable: fall back to the last saved copy
            if not _products and os.path.exists(_CACHE_FILE):
                try:
                    with open(_CACHE_FILE, encoding="utf-8") as f:
                        _products = json.load(f) or []
                except (OSError, ValueError):
                    _products = []  # empty/corrupt cache must not crash the server
            # retry Zid in ~10 minutes, not on every single search
            _loaded_at = time.time() - max(config.CATALOG_REFRESH_MINUTES - 10, 0) * 60
        return len(_products)


def _words(text: str) -> set[str]:
    return {_stem(w) for w in normalize(text).split()}


def search(query: str, limit: int = 5) -> list[dict]:
    refresh()
    q_words = [_stem(w) for w in normalize(query).split() if len(w) > 1]
    if not q_words or not _products:
        return []
    # rarer words count more (so "هالتك" beats "550")
    docs = [(_words(p["name"]), _words(" ".join([p["sku"], " ".join(p["categories"]), p["description"]]))) for p in _products]
    total = len(docs)
    q_forms = [_ALIASES.get(q, {q}) for q in q_words]
    q_weight = [math.log(1 + total / (sum(1 for n, _ in docs if forms & n) or 1)) for forms in q_forms]
    scored = []
    for p, (name_w, other_w) in zip(_products, docs):
        score, hits = 0.0, 0
        for forms, weight in zip(q_forms, q_weight):
            if forms & name_w or any(len(f) >= 3 and any(f in w for w in name_w) for f in forms):
                score += 3 * weight
                hits += 1
            elif forms & other_w:
                score += 1 * weight
        if score == 0:
            continue
        if hits == len(q_words):
            score *= 1.5
        if p["in_stock"]:
            score += 0.1
        scored.append((score, p))
    scored.sort(key=lambda x: -x[0])
    return [_public_view(p) for _, p in scored[:limit]]


def get(product_id: str) -> dict | None:
    refresh()
    for p in _products:
        if p["id"] == product_id:
            out = _public_view(p)
            out["description"] = p["description"]
            return out
    return None


def _public_view(p: dict) -> dict:
    price = p["sale_price"] or p["price"]
    return {
        "id": p["id"],
        "name": p["name"],
        "price_sar": price,
        "old_price_sar": p["price"] if p["sale_price"] else None,
        "price_note": "السعر يبدأ من هذا الرقم حسب الخيار" if p["has_options"] else "",
        "in_stock": p["in_stock"],
        "category": " / ".join(p["categories"]),
        "url": p["url"],
    }


def count() -> int:
    return len(_products)
