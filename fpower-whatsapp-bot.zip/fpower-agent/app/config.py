"""All settings come from environment variables (see .env.example)."""
import os


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


# --- Claude (the AI brain) ---
ANTHROPIC_API_KEY = _env("ANTHROPIC_API_KEY")
CLAUDE_MODEL = _env("CLAUDE_MODEL", "claude-haiku-4-5")
MAX_TOOL_ROUNDS = int(_env("MAX_TOOL_ROUNDS", "5"))

# --- Chatwoot (the inbox + mobile app) ---
CHATWOOT_URL = _env("CHATWOOT_URL", "http://chatwoot:3000").rstrip("/")
CHATWOOT_ACCOUNT_ID = _env("CHATWOOT_ACCOUNT_ID", "1")
CHATWOOT_BOT_TOKEN = _env("CHATWOOT_BOT_TOKEN")  # access token of the Agent Bot
# Access token of an admin user (Profile settings). Needed to READ the chat history:
# Chatwoot does not allow Agent Bot tokens to list messages.
CHATWOOT_USER_TOKEN = _env("CHATWOOT_USER_TOKEN")
WEBHOOK_SECRET = _env("WEBHOOK_SECRET")  # must match ?token= in the bot webhook URL

# --- Zid store ---
ZID_STORE_ID = _env("ZID_STORE_ID", "3225865")
STORE_URL = _env("STORE_URL", "https://fpowerksa.com")
CATALOG_REFRESH_MINUTES = int(_env("CATALOG_REFRESH_MINUTES", "180"))
# Optional: only needed for order tracking (Zid private app tokens)
ZID_AUTHORIZATION = _env("ZID_AUTHORIZATION")  # the "Authorization" token
ZID_MANAGER_TOKEN = _env("ZID_MANAGER_TOKEN")  # the "access_token"

# --- Business rules ---
TIMEZONE = _env("TIMEZONE", "Asia/Riyadh")
SUPPORT_HOURS = (int(_env("SUPPORT_OPEN_HOUR", "9")), int(_env("SUPPORT_CLOSE_HOUR", "23")))
HANDOFF_LABEL = _env("HANDOFF_LABEL", "يحتاج-زياد")

DATA_DIR = _env("DATA_DIR", os.path.join(os.path.dirname(os.path.dirname(__file__)), "data"))


def orders_enabled() -> bool:
    return bool(ZID_AUTHORIZATION and ZID_MANAGER_TOKEN)
