"""Web server that Chatwoot calls for every new message (Agent Bot webhook)."""
import asyncio
import hmac
import logging
from collections import OrderedDict
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request

from . import agent, catalog, chatwoot, config

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("fpower-agent")

@asynccontextmanager
async def _lifespan(_app):
    n = await asyncio.to_thread(catalog.refresh, True)
    log.info("catalog loaded: %s products, order tracking: %s", n, config.orders_enabled())
    yield


app = FastAPI(title="F POWER WhatsApp Agent", lifespan=_lifespan)
_seen: "OrderedDict[int, bool]" = OrderedDict()
_locks: dict[int, asyncio.Lock] = {}
DEBOUNCE_SECONDS = 4  # wait a moment in case the customer sends several messages in a row


@app.get("/health")
async def health() -> dict:
    return {"ok": True, "products": catalog.count(), "order_tracking": config.orders_enabled()}


@app.post("/webhook")
async def webhook(request: Request, background: BackgroundTasks, token: str = "") -> dict:
    if config.WEBHOOK_SECRET and not hmac.compare_digest(token.encode(), config.WEBHOOK_SECRET.encode()):
        raise HTTPException(status_code=403)
    data = await request.json()
    if data.get("event") != "message_created" or data.get("message_type") != "incoming" or data.get("private"):
        return {"skipped": "not an incoming customer message"}
    conv = data.get("conversation") or {}
    if conv.get("status") != "pending":
        return {"skipped": "a human is handling this chat"}
    msg_id = data.get("id")
    if msg_id in _seen:
        return {"skipped": "duplicate"}
    _seen[msg_id] = True
    while len(_seen) > 5000:
        _seen.popitem(last=False)
    background.add_task(_handle, data)
    return {"queued": True}


def _customer(data: dict) -> tuple[str, str]:
    sender = data.get("sender") or {}
    meta = ((data.get("conversation") or {}).get("meta") or {}).get("sender") or {}
    phone = sender.get("phone_number") or meta.get("phone_number") or ""
    name = sender.get("name") or meta.get("name") or ""
    if name and name.replace("+", "").isdigit():
        name = ""
    return phone, name


async def _handle(data: dict) -> None:
    conv_id = (data.get("conversation") or {}).get("id")
    msg_id = data.get("id")
    lock = _locks.setdefault(conv_id, asyncio.Lock())
    await asyncio.sleep(DEBOUNCE_SECONDS)
    async with lock:
        replied = False
        try:
            if config.CHATWOOT_USER_TOKEN:
                messages = await chatwoot.get_messages(conv_id)
            else:
                log.warning("CHATWOOT_USER_TOKEN not set — replying without chat history")
                messages = [data]
            incoming = [m for m in messages if m.get("message_type") in (0, "incoming")]
            if incoming and max(m["id"] for m in incoming) != msg_id:
                return  # a newer customer message will trigger its own reply
            if chatwoot.human_replied_last(messages):
                # someone from the team already answered in this chat: step aside
                await chatwoot.open_conversation(conv_id)
                log.info("conv %s: human already replied — bot stays quiet", conv_id)
                return
            history = chatwoot.to_history(messages)
            if not history or history[-1]["role"] != "user":
                return
            phone, name = _customer(data)
            result = await asyncio.to_thread(agent.respond, history, phone, name)
            await chatwoot.send_message(conv_id, result.reply)
            replied = True
            if result.handoff_reason:
                await chatwoot.hand_off(conv_id, result.handoff_reason)
            log.info("conv %s replied (tools=%s, handoff=%s)", conv_id,
                     [c["tool"] for c in result.tool_calls], bool(result.handoff_reason))
        except Exception:
            log.exception("conv %s failed — handing to the team", conv_id)
            try:
                if not replied:  # never send the customer a second message
                    await chatwoot.send_message(conv_id, "حياك الله 🙏 وصلت رسالتك، وبيرد عليك أحد الفريق قريب.")
                await chatwoot.hand_off(conv_id, "خطأ في البوت — راجع السجل")
            except Exception:
                log.exception("conv %s: could not even hand off", conv_id)
