"""The AI agent: sends the chat to Claude with the store tools, runs the tools,
and returns the reply text plus whether a human is needed."""
import datetime as dt
import json
from dataclasses import dataclass, field
from zoneinfo import ZoneInfo

from . import catalog, config, orders
from .prompt import SYSTEM_PROMPT

TOOLS = [
    {
        "name": "search_products",
        "description": "Search the F POWER store catalog by product name, brand, part type or SKU (Arabic or English). Returns name, price in SAR, stock and link.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string", "description": "Search words, e.g. 'تيربو 660 حصان' or 'Haltech Elite 550'"}},
            "required": ["query"],
        },
    },
    {
        "name": "get_product_details",
        "description": "Get the full description of one product by its id (from search_products).",
        "input_schema": {
            "type": "object",
            "properties": {"product_id": {"type": "string"}},
            "required": ["product_id"],
        },
    },
    {
        "name": "get_order_status",
        "description": "Get the status and tracking of the customer's order. Pass the order number if the customer gave one; leave it empty to look up their latest orders by their WhatsApp number.",
        "input_schema": {
            "type": "object",
            "properties": {"order_number": {"type": "string", "description": "Order number, digits only. Empty if unknown."}},
        },
    },
    {
        "name": "handoff_to_human",
        "description": "Transfer the conversation to the store team (Ziyad). Use for compatibility questions, installments (Tabby/Tamara), complaints, problems with orders, or anything you cannot answer confidently.",
        "input_schema": {
            "type": "object",
            "properties": {
                "reason": {"type": "string", "description": "Short reason in Arabic for the team, e.g. 'سؤال توافق: هالتك 550 مع نيسان فتك 2017 TB48'"},
            },
            "required": ["reason"],
        },
    },
]


@dataclass
class AgentResult:
    reply: str
    handoff_reason: str | None = None
    tool_calls: list = field(default_factory=list)


def _within_support_hours(now: dt.datetime | None = None) -> bool:
    now = now or dt.datetime.now(ZoneInfo(config.TIMEZONE))
    open_h, close_h = config.SUPPORT_HOURS
    return open_h <= now.hour < close_h


def _run_tool(name: str, args: dict, customer_phone: str, state: dict) -> dict:
    if name == "search_products":
        results = catalog.search(args.get("query", ""))
        return {"results": results} if results else {"results": [], "note": "no_match"}
    if name == "get_product_details":
        p = catalog.get(args.get("product_id", ""))
        return p or {"error": "not_found"}
    if name == "get_order_status":
        num = (args.get("order_number") or "").strip()
        return orders.lookup(num, customer_phone) if num else orders.latest_for_phone(customer_phone)
    if name == "handoff_to_human":
        state["handoff"] = args.get("reason") or "تحويل للفريق"
        if _within_support_hours():
            return {"ok": True, "note": "تم التحويل. قل للعميل إن أحد الفريق بيرد عليه قريب."}
        open_h = config.SUPPORT_HOURS[0]
        return {"ok": True, "note": f"تم التحويل، لكن الحين خارج أوقات الدوام. قل للعميل إن الفريق بيرد عليه من الساعة {open_h} الصبح."}
    return {"error": "unknown_tool"}


def _client():
    import anthropic

    return anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)


def respond(history: list[dict], customer_phone: str, customer_name: str = "", client=None) -> AgentResult:
    """history: list of {"role": "user"|"assistant", "content": str}, oldest first,
    ending with the customer's latest message."""
    client = client or _client()
    system = SYSTEM_PROMPT
    if customer_name:
        system += f"\n\nاسم العميل في الواتساب: {customer_name} (استخدمه بلطف إذا كان اسم حقيقي)."
    messages = [dict(m) for m in history]
    state: dict = {}
    calls = []
    for _ in range(config.MAX_TOOL_ROUNDS):
        resp = client.messages.create(
            model=config.CLAUDE_MODEL,
            max_tokens=700,
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            tools=TOOLS,
            messages=messages,
        )
        if resp.stop_reason != "tool_use":
            text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text").strip()
            return AgentResult(text or _fallback(state), state.get("handoff"), calls)
        messages.append({"role": "assistant", "content": resp.content})
        results = []
        for block in resp.content:
            if getattr(block, "type", "") != "tool_use":
                continue
            out = _run_tool(block.name, block.input or {}, customer_phone, state)
            calls.append({"tool": block.name, "input": block.input, "output": out})
            results.append({"type": "tool_result", "tool_use_id": block.id,
                            "content": json.dumps(out, ensure_ascii=False)})
        messages.append({"role": "user", "content": results})
    # Too many tool rounds: play safe and hand over
    state.setdefault("handoff", "البوت ما قدر يكمل الرد (حلقة أدوات طويلة)")
    return AgentResult(_fallback(state), state["handoff"], calls)


def _fallback(state: dict) -> str:
    return "أبشر، حولت سؤالك لأحد الفريق وبيرد عليك قريب 🙏"
