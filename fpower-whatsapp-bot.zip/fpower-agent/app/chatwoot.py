"""Small client for the Chatwoot API, using the Agent Bot's token."""
import httpx

from . import config


def _url(path: str) -> str:
    return f"{config.CHATWOOT_URL}/api/v1/accounts/{config.CHATWOOT_ACCOUNT_ID}{path}"


def _headers(token: str = "") -> dict:
    return {"api_access_token": token or config.CHATWOOT_BOT_TOKEN, "Content-Type": "application/json"}


async def get_messages(conversation_id: int) -> list[dict]:
    # Chatwoot only lets Agent Bot tokens *create* messages, not list them (401),
    # so reading the history needs a user (admin) access token.
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.get(_url(f"/conversations/{conversation_id}/messages"),
                        headers=_headers(config.CHATWOOT_USER_TOKEN))
        r.raise_for_status()
        return r.json().get("payload", [])


async def send_message(conversation_id: int, content: str, private: bool = False) -> None:
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.post(_url(f"/conversations/{conversation_id}/messages"), headers=_headers(),
                         json={"content": content, "message_type": "outgoing", "private": private})
        r.raise_for_status()


async def hand_off(conversation_id: int, reason: str) -> None:
    """Move the chat from the bot to the team: private note + label + status open."""
    async with httpx.AsyncClient(timeout=20) as c:
        await c.post(_url(f"/conversations/{conversation_id}/messages"), headers=_headers(),
                     json={"content": f"🤖 تحويل من البوت: {reason}", "message_type": "outgoing", "private": True})
        await c.post(_url(f"/conversations/{conversation_id}/labels"), headers=_headers(),
                     json={"labels": [config.HANDOFF_LABEL]})
        r = await c.post(_url(f"/conversations/{conversation_id}/toggle_status"), headers=_headers(),
                         json={"status": "open"})
        r.raise_for_status()


async def open_conversation(conversation_id: int) -> None:
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.post(_url(f"/conversations/{conversation_id}/toggle_status"), headers=_headers(),
                         json={"status": "open"})
        r.raise_for_status()


def human_replied_last(messages: list[dict]) -> bool:
    """True if the latest public outgoing message was written by a person (not the bot).
    Chatwoot keeps a webhook-bot chat 'pending' even after an agent replies, so we check this ourselves."""
    outs = [m for m in messages if m.get("message_type") in (1, "outgoing") and not m.get("private")]
    if not outs:
        return False
    last = max(outs, key=lambda m: (m.get("created_at") or 0, m.get("id") or 0))
    return (last.get("sender") or {}).get("type") == "user" or bool(
        (last.get("content_attributes") or {}).get("external_echo"))


def to_history(messages: list[dict], limit: int = 20) -> list[dict]:
    """Chatwoot messages -> Claude chat history (user/assistant, alternating, ends with user)."""
    turns: list[dict] = []
    for m in sorted(messages, key=lambda x: x.get("created_at", 0)):
        if m.get("private"):
            continue
        mtype = m.get("message_type")
        if mtype in (0, "incoming"):
            role = "user"
        elif mtype in (1, 3, "outgoing", "template"):
            role = "assistant"
        else:
            continue
        text = (m.get("content") or "").strip()
        if not text and m.get("attachments"):
            kinds = ", ".join(sorted({a.get("file_type", "file") for a in m["attachments"]}))
            text = f"[أرسل العميل مرفق: {kinds}]" if role == "user" else "[مرفق]"
        if not text and role == "user":
            text = "[أرسل العميل رسالة من نوع غير مدعوم]"  # keep the chat ending with the customer
        if not text:
            continue
        if turns and turns[-1]["role"] == role:
            turns[-1]["content"] += "\n" + text
        else:
            turns.append({"role": role, "content": text})
    turns = turns[-limit:]
    while turns and turns[0]["role"] != "user":
        turns.pop(0)
    return turns
