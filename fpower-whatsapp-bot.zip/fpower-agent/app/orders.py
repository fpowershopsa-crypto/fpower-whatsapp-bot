"""Order status from Zid (needs private-app tokens). Only reveals an order to the
customer whose WhatsApp number matches the phone on the order."""
import re

import httpx

from . import config

_BASE = "https://api.zid.sa/v1/managers/store/orders"

_STATUS_AR = {
    "new": "جديد – استلمنا طلبك",
    "preparing": "جاري التجهيز",
    "ready": "جاهز للشحن",
    "indelivery": "انشحن وفي الطريق لك",
    "delivered": "تم التوصيل",
    "canceled": "ملغي",
    "cancelled": "ملغي",
}


def _last9(phone: str) -> str:
    digits = re.sub(r"\D", "", phone or "")
    return digits[-9:]


def _valid_phone(phone: str) -> bool:
    return len(_last9(phone)) == 9


def _headers() -> dict:
    return {
        "Authorization": f"Bearer {config.ZID_AUTHORIZATION}",
        "X-Manager-Token": config.ZID_MANAGER_TOKEN,
        "Accept-Language": "ar",
    }


def _summarise(order: dict) -> dict:
    status = (order.get("order_status") or {}).get("code") or ""
    display = (order.get("display_status") or {}).get("name") or ""
    shipping = (order.get("shipping") or {}).get("method") or {}
    tracking = shipping.get("tracking") or {}
    return {
        "order_id": order.get("id"),
        "status": display or _STATUS_AR.get(status.lower(), status),
        "payment_status": order.get("payment_status"),
        "shipping_company": (shipping.get("courier") or {}).get("name") if isinstance(shipping.get("courier"), dict) else shipping.get("name"),
        "tracking_number": tracking.get("number"),
        "tracking_url": tracking.get("url"),
        "created_at": order.get("created_at"),
    }


def lookup(order_id: str, customer_phone: str) -> dict:
    """Return a safe summary, or an error the bot can act on."""
    if not config.orders_enabled():
        return {"error": "order_tracking_not_connected"}
    order_id = re.sub(r"\D", "", order_id or "")
    if not order_id:
        return {"error": "missing_order_number"}
    try:
        r = httpx.get(f"{_BASE}/{order_id}/view", headers=_headers(), timeout=20)
    except httpx.HTTPError:
        return {"error": "zid_unreachable"}
    if r.status_code == 404:
        return {"error": "order_not_found"}
    if r.status_code != 200:
        return {"error": f"zid_error_{r.status_code}"}
    order = r.json().get("order") or r.json()
    order_phone = (order.get("customer") or {}).get("mobile") or ""
    if not _valid_phone(customer_phone) or _last9(order_phone) != _last9(customer_phone):
        # Never reveal someone else's order
        return {"error": "phone_does_not_match_order"}
    return _summarise(order)


def latest_for_phone(customer_phone: str) -> dict:
    if not config.orders_enabled():
        return {"error": "order_tracking_not_connected"}
    if not _valid_phone(customer_phone):
        # an empty phone would otherwise "match" orders that have no mobile on them
        return {"error": "no_orders_for_this_phone"}
    try:
        r = httpx.get(_BASE, headers=_headers(), timeout=20,
                      params={"search_term": _last9(customer_phone), "per_page": 5, "page": 1})
    except httpx.HTTPError:
        return {"error": "zid_unreachable"}
    if r.status_code != 200:
        return {"error": f"zid_error_{r.status_code}"}
    orders = r.json().get("orders") or []
    mine = [o for o in orders if _last9((o.get("customer") or {}).get("mobile") or "") == _last9(customer_phone)]
    if not mine:
        return {"error": "no_orders_for_this_phone"}
    return {"orders": [_summarise(o) for o in mine[:3]]}
