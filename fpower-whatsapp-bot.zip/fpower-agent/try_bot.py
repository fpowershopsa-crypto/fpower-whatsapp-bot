"""Talk to the bot in the terminal before connecting WhatsApp.

    ANTHROPIC_API_KEY=... python try_bot.py            # chat yourself
    ANTHROPIC_API_KEY=... python try_bot.py --scenarios # run the standard test chats
"""
import sys

from app import agent, catalog

SCENARIOS = [
    ["السلام عليكم"],
    ["كم سعر كمبيوتر هالتك 550؟"],
    ["عندكم تيربو يطلع 660 حصان؟", "متوفر؟ وكم الشحن للرياض"],
    ["كم ياخذ الشحن للكويت؟"],
    ["ابي ارجع قطعة شريتها قبل 3 ايام وما فتحتها"],
    ["القطعة وصلتني خربانة"],
    ["هل الهالتك ايليت 550 يركب على فتك 2017 TB48؟"],
    ["عندكم تقسيط تمارا؟"],
    ["وين طلبي رقم 75341764"],
    ["عندكم بيتزا؟"],
    ["Do you ship to Dubai?"],
    ["ابي اكلم زياد"],
]


def run(history_msgs: list[str], phone: str = "+966500000001") -> None:
    history: list[dict] = []
    for text in history_msgs:
        history.append({"role": "user", "content": text})
        res = agent.respond(history, phone, "")
        tools = ", ".join(c["tool"] for c in res.tool_calls) or "-"
        print(f"👤 {text}\n🤖 {res.reply}\n   [أدوات: {tools}] [تحويل: {res.handoff_reason or 'لا'}]\n")
        history.append({"role": "assistant", "content": res.reply})


def main() -> None:
    print("تحميل المنتجات...", catalog.refresh(True), "منتج\n")
    if "--scenarios" in sys.argv:
        for s in SCENARIOS:
            print("=" * 60)
            run(s)
        return
    history: list[dict] = []
    while True:
        try:
            text = input("👤 أنت: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not text:
            continue
        history.append({"role": "user", "content": text})
        res = agent.respond(history, "+966500000001", "")
        print("🤖", res.reply)
        if res.handoff_reason:
            print("   ↪ تحويل للفريق:", res.handoff_reason)
        history.append({"role": "assistant", "content": res.reply})


if __name__ == "__main__":
    main()
